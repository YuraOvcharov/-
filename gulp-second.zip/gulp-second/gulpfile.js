"use strict";

// =======================================================================
// Modules
// =======================================================================

var argv          = require('yargs').argv,
    browserSync   = require('browser-sync'),
    cache         = require('gulp-cache'),
    cssnano       = require('gulp-cssnano'),
    concat        = require('gulp-concat'),
    del           = require('del'),
    gulp          = require('gulp'),
    gulpif        = require('gulp-if'),
    htmlmin       = require('gulp-htmlmin'),
    imagemin      = require('gulp-imagemin'),
    jshint        = require('gulp-jshint'),
    newer         = require('gulp-newer'),
    // pngquant      = require('imagemin-pngquant'),
    autoprefixer  = require('gulp-autoprefixer'),
    runSequence   = require('run-sequence'),
    sass          = require('gulp-sass'),
    size          = require('gulp-size'),
    sourcemaps    = require('gulp-sourcemaps'),
    stylish       = require('jshint-stylish'),
    uglify        = require('gulp-uglify'),
    useref        = require('gulp-useref');

var reload = browserSync.reload;


// Styles Tasks
gulp.task('styles', function() {
    var AUTOPREFIXER_BROWSERS = [
        'ie >= 10',
        'ie_mob >= 10',
        'ff >= 30',
        'chrome >= 34',
        'safari >= 7',
        'opera >= 23',
        'ios >= 7',
        'android >= 4.4',
        'bb >= 10'
    ];

    return gulp.src([
        // Import fonts at the beginning of the css file
        'src/styles/import-fonts.scss',

        // Libraries
        'bower_components/toastr/toastr.min.css',
        'bower_components/bootstrap-daterangepicker/daterangepicker.css',
        'bower_components/bootstrap-select/dist/css/bootstrap-select.min.css',
        'bower_components/owl.carousel/dist/assets/owl.carousel.min.css',

        // Custom Styles
        'src/styles/main.scss',
    ])
        .pipe(newer('.tmp/styles'))
        .pipe(gulpif(!argv.production, sourcemaps.init()))
        .pipe(sass({
          precision: 10
        }).on('error', sass.logError))
        .pipe(autoprefixer(AUTOPREFIXER_BROWSERS))
        // Concatenate and minify styles
        .pipe(concat('main.min.css'))
        .pipe(gulpif(argv.production, cssnano({
            discardComments: {
                removeAll: true // enable this if you want remove all comments
            }
        })))
        .pipe(size({title: 'styles'}))
        .pipe(gulpif(!argv.production, sourcemaps.write()))
        .pipe(gulp.dest('.tmp/styles/'))
        .pipe(gulp.dest('public/styles/'))
        .pipe(browserSync.stream());
});


// Lint JavaScript
gulp.task('lint', function() {
    gulp.src('src/**/*.js')
        .pipe(jshint()) // view what is it
        .pipe(jshint.reporter(stylish)); // view what is it
});
// gulp.task('lint', () =>
//     gulp.src('src/js/**/*.js')
//         .pipe($.eslint())
//         .pipe($.eslint.format())
//         .pipe($.if(!browserSync.active, $.eslint.failOnError()))
// );


// Scan your HTML for assets & optimize them
gulp.task('html', function() {
    return gulp.src('src/**/*.html')
        .pipe(useref({
            searchPath: '{.tmp, src}',
            noAssets: true
        }))

        // Minify any HTML
        // .pipe(gulpif('*.html', htmlmin({
        //     removeComments: true,
        //     collapseWhitespace: true,
        //     collapseBooleanAttributes: true,
        //     removeAttributeQuotes: true,
        //     removeRedundantAttributes: false,
        //     removeEmptyAttributes: true,
        //     removeScriptTypeAttributes: true,
        //     removeStyleLinkTypeAttributes: true,
        //     removeOptionalTags: true
        // })))

        // Output files
        .pipe(gulpif('*.html', size({title: 'html', showFiles: true})))
        .pipe(gulp.dest('public'));
});


// Scripts Tasks
gulp.task('scripts', function () {
    gulp.src([
        // Libraries
        'bower_components/jquery/dist/jquery.min.js',
        'bower_components/tether/dist/js/tether.min.js',
        'bower_components/moment/moment.js',
        'bower_components/bootstrap/dist/js/bootstrap.min.js',
        'bower_components/owl.carousel/dist/owl.carousel.min.js',
        'bower_components/jquery-validation/dist/jquery.validate.js',
        'bower_components/jquery-ui/jquery-ui.min.js',
        'bower_components/bootstrap-daterangepicker/daterangepicker.js',
        'bower_components/jquery-validation/src/localization/messages_ru.js',
        'bower_components/jquery-mask-plugin/dist/jquery.mask.min.js',
        'bower_components/toastr/toastr.min.js',


        // Custom scripts
        'src/scripts/main.js'
    ])
        .pipe(newer('.tmp/scripts'))
        .pipe(gulpif(!argv.production, sourcemaps.init()))
        .pipe(concat('main.min.js'))
        .pipe(gulpif(argv.production, uglify({
            preserveComments: 'license',
            output: {
                ascii_only: true // not convert text \u041E
            }
        })))
        // Output files
        .pipe(size({title: 'scripts'}))
        .pipe(gulpif(!argv.production, sourcemaps.write('.')))
        .pipe(gulp.dest('.tmp/scripts'))
        .pipe(gulp.dest('public/scripts'))
        //.pipe(reload({stream: true}));
        .pipe(browserSync.stream());
});


// Images Task
gulp.task('images', function() {
    return gulp.src('src/images/**/*')
        .pipe(gulpif(argv.production,
            cache(imagemin({
                progressive: true,
                interlaced: true,
                pngquant: true
            }))
        ))
        .pipe(gulp.dest('public/images'))
        .pipe(size({title: 'images'}))
});


// Copy all files at the root level
gulp.task('copy', function () {
    return gulp.src([
        'src/**/*.{ttf,woff,eot,svg}',
        'src/*',
        '!src/*.html'
    ])
        .pipe(gulp.dest('public'))
        .pipe(gulp.dest('.tmp'))
        .pipe(size({title: 'copy'}))
});


// Clean output directory
gulp.task('clean', function() {
    del([
        '.tmp',
        'public',
        '!dist/.git'
    ], {force: true})
});



// Watch files for changes & reload
gulp.task('serve', ['scripts', 'styles'], function() {
    browserSync({
        notify: false,
        // Customize the Browsersync console logging prefix
        logPrefix: 'MS',
        // Allow scroll syncing across breakpoints
        // scrollElementMapping: ['.site'],
        // Run as an https by uncommenting 'https: true'
        // Note: this uses an unsigned certificate which on first access
        //       will present a certificate warning in the browser.
        // https: true,
        // server: ['.tmp', 'src'],
        server: {
            baseDir: ['.tmp', 'src'],
            routes: {
                '/bower_components': 'bower_components'
            }
        },
        port: 3000
    });

    gulp.watch(['src/**/*.html'], reload);
    gulp.watch(['src/styles/**/*.{scss,css}'], ['styles']);
    gulp.watch(['src/scripts/**/*.js'], ['lint', 'scripts']);
    gulp.watch(['src/images/**/*'], reload);
});


// Build production files, the default task
gulp.task('default', ['clean'], function(cb) {
    runSequence(
        'styles',
        ['lint', 'html', 'scripts', 'images', 'copy'],
        cb
    )
});


// Run PageSpeed Insights
gulp.task('pagespeed', function(cb) {
    // Update the below URL to the public URL of your site
    pagespeed('example.com', {
        strategy: 'mobile'
        // By default we use the PageSpeed Insights free (no API key) tier.
        // Use a Google Developer API key if you have one: http://goo.gl/RkN0vE
        // key: 'YOUR_API_KEY'
    }, cb)
});