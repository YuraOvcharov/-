var app = (function() {
    return {
        init: function() {

            this.topPanelFixed();
            this.bindEvents();
        },

        bindEvents: function() {
            var _this = this;


        },

        topPanelFixed: function(e) {
        	var panel = $('.top-panel');
	    	var height = panel.outerHeight();
	    	var pseudoPanel = $('<div class="top-panel__pseudo" style="height: '+height+'px;"></div>');

	    	panel
	    		.addClass('top-panel--fixed')
	    		.after(pseudoPanel);
        }
    };
}());

app.init();



var alarm = (function() {
    var sendingState = false;
    var alarmButton = $( ".alarm-dragger-button" );

    return {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {

            alarmButton.draggable({
			  	axis: "x",
			  	containment: "parent",
			  	revert: true,
			  	drag: function() {

			  		var railWidth = $('.alarm-dragger-rail').outerWidth();
			  		var buttonWidth = $('.alarm-dragger-button').outerWidth();
			  		var point = railWidth - buttonWidth;
			        var position = $(this).position().left;

			        if (position === point && !sendingState) {
			        	console.log( 'отправляем Alarm на сервак' );
			        	$('#alarmModal').removeClass('in');
			        	$('#alarmSendModal').modal('show');

			        	$('#alarmSendModal').on('hidden.bs.modal', function (e) {
		                    $('#alarmModal').modal('hide');
		                });
			        	sendingState = true;

			        	$(this).draggable( "disable" );
			        	$(this).draggable( "option", "revert", false );
			        }
			    }
			});
        }
    };

}());

alarm.init();




var inputFile = (function() {

    var el;
    var clearButton;
    var input;
    var toggle;
    var placeholder;

    function inputChange(e) {
        var field = $(e.currentTarget).closest('.upload-file');
        var toggle = field.find('.upload-file__toggle');
        var text = toggle.find('span');
        var input = field.find('.upload-file__input');
        var filename = input.val().split('\\').pop();

        if (filename === '') {
            inputFile.clearField(field);
        } else {
            field.addClass('upload-file--added');
            text.text(filename);
        }
    }

    return {
        init: function() {

        	el = $('.upload-file');
		    clearButton = el.find('.upload-file__clear');
		    input = el.find('.upload-file__input');
		    toggle = el.find('.upload-file__toggle');
		    title = el.find('.upload-file__toggle span');
            placeholder = title.data('placeholder');

            this.bindEvents();
        },

        bindEvents: function() {

            toggle.click(function(event) {
                input.click();
            });

            input.change(function (e) {
                inputChange(e);
            });

            clearButton.click( $.proxy(this.clearField, this) );
        },

        clearField: function(e) {
        	var field = $(e.currentTarget).closest('.upload-file');
            var toggle = field.find('.upload-file__toggle');
            var text = toggle.find('span');
            var placeholder = toggle.data('placeholder');
            var input = field.find('.upload-file__input');

            input.val('');
            field.removeClass('upload-file--added');
            text.text(placeholder);
        }
    };
}());

inputFile.init();



// $('.form-control-date').datepicker({
//     isRTL: false,
//     dateFormat: 'dd.mm.yy',
//     autoclose: true,
//     language: 'ru'
// });

$(function() {
	$('.js-daterangepicker').daterangepicker({
		locale: {
            format: 'DD.MM.YYYY',
            separator: ' - ',
            applyLabel: 'Применить',
            cancelLabel: 'Отмена',
	        daysOfWeek: [
	            "Вс",
	            "Пн",
	            "Вт",
	            "Ср",
	            "Чт",
	            "Пт",
	            "Сб"
	        ],
	        monthNames: [
	            "Январь",
	            "Февраль",
	            "Март",
	            "Апрель",
	            "Май",
	            "Июнь",
	            "Июль",
	            "Август",
	            "Сентябрь",
	            "Октябрь",
	            "Ноябрь",
	            "Декабрь"
	        ],
	        firstDay: 1
	    }
	});
});



var filter = (function() {

    return {
        init: function() {
            $('.filter__collapse-toggle').click($.proxy(this.collapseFilter, this));
        },

        collapseFilter: function(e) {
            var toggle;

            if (typeof e !== 'undefined') {
                console.log( '1' );
                toggle = $(e.currentTarget);
            } else {
                console.log( '2' );
                toggle = $('.filter__collapse-toggle');
            }


            var filterEl = toggle.closest('.filter');
            var filterCollapseContent = filterEl.find('.filter__collapse-content');

            console.log( filterEl );

            if (filterEl.is('.filter--collapsed')) {
                filterEl.removeClass('filter--collapsed');
                filterCollapseContent.css('margin-top', -filterCollapseContent.outerHeight() + 'px');

                toggle.text('Скрыть');
            } else {
                filterEl.addClass('filter--collapsed');

                filterCollapseContent.css('margin-top', 0);
                toggle.text('Показать');
            }

            this.setHeight(filterEl);

        },
        setHeight: function(filterEl) {
            var height = filterEl.find('.filter__content').outerHeight();
            var filterCollapseContent = filterEl.find('.filter__collapse-content');

            if (filterEl.is('.filter--collapsed')) {
                // filterEl.removeAttr('style');
                filterEl.css('height', filterCollapseContent.outerHeight()+'px');
            } else {
                filterEl.css('height', height+'px');
            }
        }
    };
}());

filter.init();


function openTab(tab) {
    $('.nav-tabs a[href="#' + tab + '"]').tab('show');
}

var controlPassword = (function() {

    return {
        init: function() {


            this.bindEvents();
        },

        bindEvents: function() {
            var _this = this;

            $('.password__visible-toggle').click( $.proxy(this.togglePassword,this) );
        },

        togglePassword: function(e) {
            var inputContainer = $(e.currentTarget).closest('.password');
            var input = inputContainer.find('.password__input');

            if (inputContainer.is('.password--visible')) {
                inputContainer.removeClass('password--visible');
                input.attr('type', 'password');
            } else {
                inputContainer.addClass('password--visible');
                input.attr('type', 'text');
            }
        }
    };
}());

controlPassword.init();





$(function() {
    // Настройки для всплывающих уведомлений
    toastr.options.positionClass = "toast-top-center";
});
