//$('#enter-login').mask('70000000000');
$('#enter-login').mask('0#');
$('.mask-price').mask('0#');

/**************************** Проверка полей ****************************/
    $(function() {
        $('.login').each(function(){
            // Объявляем переменные (форма и кнопка отправки)
            var form = $(this),
                btn = form.find('.btn-login');
            btn.addClass('disabled');
            // Добавляем каждому проверяемому полю, указание что поле пустое
            form.find('.admin-panel-input').addClass('empty-input');

            // Функция проверки полей формы
            function checkInput(){  
                form.find('.admin-panel-input').each(function(){
                    if($(this).val() != ''){
                        // Если поле не пустое удаляем класс-указание .
                        $(this).next('.login-error').removeAttr('style');
                        $(this).removeAttr('style');
                        $(this).removeClass('empty-input');
                    } else {
                        // Если поле пустое добавляем класс-указание
                        $(this).addClass('empty-input');
                    }
                });
            }
            // Функция подсветки незаполненных полей
            function lightEmpty(){
                form.find('.empty-input').css({'border-color':'#d8512d'});
                $(".login-error").css("visibility","visible");
            }
            // Проверка в режиме реального времени
            setInterval(function(){

                // Запускаем функцию проверки полей на заполненность
                checkInput();
                // Считаем к-во незаполненных полей    
                var sizeEmpty = form.find('.empty-input').size();
                // Вешаем условие-тригер на кнопку отправки формы
                if(sizeEmpty > 0){
                    if(btn.hasClass('disabled')){
                        return false
                    } else {
                        btn.addClass('disabled')
                    }
                } else {
                    btn.removeClass('disabled')
                }
            },10);//,1000
            

            // Событие клика по кнопке отправить
            btn.click(function(){
                if($(this).hasClass('disabled')){
                    // подсвечиваем незаполненные поля и форму не отправляем, если есть незаполненные поля
                    lightEmpty();
                    return false
                } else {
                        console.log("all good");
                        // Все хорошо, все заполнено, отправляем форму
                        location.href = "Change-organization.html";

                }
            });
        });
    }); 
/***************************Add image************************************/  
$(function(){ 
    $('.admin-body-wrap').each(function(){
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('.cover-img').css("background-image", "url('" + e.target.result + "')");
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        $("#bitmap__upload").change(function() {
            readURL(this);
        });
        
        $('.load-img').on('click', function() {
            $('#bitmap__upload').trigger('click');
        });
    });
});
/************************** AJAX load *******************************/
$(function(){
    $('#app').click(function(){
        $("#admin-body").load("/ajax-html/app.html");
    })
    $('#install-logo').click(function(){
        $("#admin-body").load("/ajax-html/install-logo.html");
    })
    $('#address').click(function(){
        $("#admin-body").load("/ajax-html/address.html");
    })
    $('.open-address-edit').click(function(){
        $("#admin-body").load("/ajax-html/address-edit.html");
    });
    
    $('#catalogs').click(function(){
        $("#admin-body").load("/ajax-html/catalogs.html");
    })
    $('.open-catalogs-edit').click(function(){
        $("#admin-body").load("/ajax-html/catalogs_edit.html");
    });
    
    $('#album').click(function(){
        $("#admin-body").load("/ajax-html/album.html");
    })
    $('.call-album-edit').click(function(){
       $("#admin-body").load("/ajax-html/album_edit.html");
    });
    
    $('#video').click(function(){
        $("#admin-body").load("/ajax-html/video.html");
    })
    $('.call-video-edit').click(function(){
        $("#admin-body").load("/ajax-html/video_edit.html");
    });
    
    $('#posts').click(function(){
        $("#admin-body").load("/ajax-html/posts.html");
    })
    $('#users').click(function(){
        $("#admin-body").load("/ajax-html/users.html");
    })
    $('#modifications').click(function(){
        $("#admin-body").load("/ajax-html/modifications.html");
    })
    $('.open-modifications-edit').click(function(){
       $("#admin-body").load("/ajax-html/modifications-edit.html");
    });
        
});
/*************************** Click ************************************/
$(function(){
    $('.btn-edit-event').click(function(){
        location.href = "AdminPanel.html";
    });
});

$(function(){
    $('.btn-for-del-img').click(function(){
        $(this).prev().addClass('grid-img__deleted');
        $(this).addClass('btn-for-del-img__deleted')
        //$(this).remove();
       // $(this).text( 'Удаленно');
        $( ".grid__row-item" ).off( "click", this).find( this ).text( "Удаленна" );
    });
});
$(function(){
    $('.admin-list__link, .admin-body').click(function(){
        document.getElementById("menu-toggle").checked = false;
    });
});
/************************** Add class on menu *******************************/
$(function(){ 
    $('.admin-list').each(function(){
		$('.admin-list__link').click(function(e) {
			e.preventDefault();
			$('.admin-list__link').removeClass('active');
			$(this).addClass('active');
		});
	});
});