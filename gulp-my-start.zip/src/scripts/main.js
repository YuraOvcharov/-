/************************** AJAX *******************************/
/*$(function(){
    $('#app').click(function(){
        $("#admin-body").load("/ajax-html/app.html");
    })
    $('#install-logo').click(function(){
        $("#admin-body").load("/ajax-html/install-logo.html");
    })
    $('#address').click(function(){
        $("#admin-body").load("/ajax-html/address.html");
    })
});*/
/*Подключи js*/
/************************** Add class on menu *******************************/
/*$(function(){ 
    $('.admin-list').each(function(){
		$('.admin-list__link').click(function(e) {
			e.preventDefault();
			$('.admin-list__link').removeClass('active');
			$(this).addClass('active');
		});
	});
});*/